const allowedOrigins = [
  'http://localhost:8000'
]

module.exports = allowedOrigins
